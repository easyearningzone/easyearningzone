import { useState, useEffect } from 'react';
import { User, Wallet } from '../types';
import { apiService } from '../lib/db';

interface AdViewPageProps {
  user: User;
  wallet: Wallet | null;
  onRefreshTrigger: () => void;
  onBack: () => void;
}

export default function AdViewPage({ user, wallet, onRefreshTrigger, onBack }: AdViewPageProps) {
  // Navigation tabs within Ad view page: 'ad_panel', 'history', 'transfer'
  const [activeSubTab, setActiveSubTab] = useState<'ad_panel' | 'history' | 'transfer'>('ad_panel');
  
  // Daily ads watch limit and balance
  const [adBalance, setAdBalance] = useState<number>(() => {
    const saved = localStorage.getItem(`ad_balance_${user.id}`);
    return saved ? parseFloat(saved) : 7.50; // default start placeholder
  });

  const [adsWatched, setAdsWatched] = useState<number>(() => {
    const saved = localStorage.getItem(`ads_watched_${user.id}`);
    return saved ? parseInt(saved, 10) : 20; // default starting watch count
  });

  // Watch count resetting (can reset every 24 hours or mock daily reset)
  useEffect(() => {
    localStorage.setItem(`ad_balance_${user.id}`, adBalance.toFixed(2));
  }, [adBalance, user.id]);

  useEffect(() => {
    localStorage.setItem(`ads_watched_${user.id}`, adsWatched.toString());
  }, [adsWatched, user.id]);

  // Timer & state
  const [timeLeft, setTimeLeft] = useState<number>(30);
  const [isWatching, setIsWatching] = useState<boolean>(false);
  const [isCheckingSecurity, setIsCheckingSecurity] = useState<boolean>(false);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [historyList, setHistoryList] = useState<{ id: string; time: string; amount: number; platform: string }[]>(() => {
    const saved = localStorage.getItem(`ad_history_${user.id}`);
    return saved ? JSON.parse(saved) : [
      { id: '1', time: new Date(Date.now() - 3600000 * 2).toLocaleTimeString('bn-BD'), amount: 0.30, platform: 'Monetag Ad' },
      { id: '2', time: new Date(Date.now() - 3600000 * 4).toLocaleTimeString('bn-BD'), amount: 0.30, platform: 'Adsterra Ad' },
      { id: '3', time: new Date(Date.now() - 3600000 * 6).toLocaleTimeString('bn-BD'), amount: 0.30, platform: 'Adsterra Ad' }
    ];
  });

  // Transfer state
  const [transferAmount, setTransferAmount] = useState<string>('');
  const [transferError, setTransferError] = useState<string>('');
  const [transferSuccess, setTransferSuccess] = useState<string>('');

  const directAdLink = "https://www.effectivecpmnetwork.com/beyqdkhv?key=53b1c1b08afd111bfffe309361f84a14";

  // Security Check: Simulated VPN or AD BLOCKER logic
  const checkVpnOrDns = (): Promise<boolean> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
        // Bangladesh timezone check
        if (!timezone.includes("Asia/Dhaka") && !timezone.includes("Asia/Calcutta") && !timezone.includes("Asia/Katmandu")) {
          resolve(true); // VPN suspicious
          return;
        }
        resolve(false); // Clean
      }, 1500);
    });
  };

  const startAdWatching = async () => {
    if (isWatching) return;
    if (adsWatched >= 25) {
      fireAlert('লিমিট শেষ 🚫', 'আপনার আজকের ২৫টি বিজ্ঞাপন দেখার দৈনিক লিমিট শেষ হয়ে গিয়েছে। আগামীকাল আবার চেষ্টা করুন!', 'warning');
      return;
    }

    setIsCheckingSecurity(true);

    const isSuspicious = await checkVpnOrDns();
    setIsCheckingSecurity(false);

    if (isSuspicious) {
      fireAlert(
        'ভিপিএন বা ডিএনএস সনাক্ত হয়েছে! 🌐',
        'অনুগ্রহ করে আপনার ফোনের VPN, AdGuard, NextDNS বা যেকোনো অ্যাড ব্লকার সার্ভিস বন্ধ করে আবার চেষ্টা করুন। অন্যথায় বিজ্ঞাপন লোড হবে না।',
        'warning'
      );
      return;
    }

    // Set precise watch clock parameters
    setIsWatching(true);
    setStartTime(Date.now());
    setTimeLeft(30);

    // Open direct ad link in a new tab
    window.open(directAdLink, '_blank', 'noopener,noreferrer');
  };

  // Timer countdown hook using real elapsed time to prevent background lag bypass
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isWatching && startTime !== null) {
      interval = setInterval(() => {
        const elapsed = Math.floor((Date.now() - startTime) / 1000);
        const left = Math.max(30 - elapsed, 0);
        setTimeLeft(left);
        if (left <= 0) {
          if (interval) clearInterval(interval);
        }
      }, 500);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isWatching, startTime]);

  // Tab focus strict alignment validation
  useEffect(() => {
    const verifyAndProcessAdTiming = () => {
      if (isWatching && startTime !== null) {
        const elapsedSeconds = Math.floor((Date.now() - startTime) / 1000);
        
        if (elapsedSeconds < 30) {
          // USER RETURNED WORKSPACE TOO EARLY (= Trick/Minimize/Tab change detected)
          setIsWatching(false);
          setStartTime(null);
          setTimeLeft(30);
          fireAlert(
            'বিজ্ঞাপন সম্পূর্ণ দেখা হয়নি! ❌',
            'সদস্য, নির্দিষ্ট ৩০ সেকেন্ড বিজ্ঞাপনটি সম্পূর্ণ না দেখেই আপনি আমাদের ড্যাশবোর্ডে ফিরে এসেছেন! তাই আপনার রিওয়ার্ডটি বাতিল করা হয়েছে। আবার প্রথম থেকে সম্পূর্ণ দেখুন।',
            'error'
          );
        } else {
          // Success: User stayed on ad/tab for at least 30 seconds clock time
          setIsWatching(false);
          setStartTime(null);
          setTimeLeft(30);
          claimReward();
        }
      }
    };

    const handleVisibilityChange = () => {
      if (!document.hidden) {
        verifyAndProcessAdTiming();
      }
    };

    const handleWindowFocus = () => {
      verifyAndProcessAdTiming();
    };

    document.addEventListener("visibilitychange", handleVisibilityChange);
    window.addEventListener("focus", handleWindowFocus);

    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
      window.removeEventListener("focus", handleWindowFocus);
    };
  }, [isWatching, startTime]);

  const claimReward = () => {
    const rewardBdt = 0.30;
    
    // Update local balances
    setAdBalance(prev => prev + rewardBdt);
    setAdsWatched(prev => prev + 1);

    // Add record to history
    const newRecord = {
      id: Math.random().toString(),
      time: new Date().toLocaleTimeString('bn-BD'),
      amount: rewardBdt,
      platform: Math.random() > 0.5 ? 'Adsterra Video Ad' : 'Monetag Partner Ad'
    };
    const updatedHistory = [newRecord, ...historyList];
    setHistoryList(updatedHistory);
    localStorage.setItem(`ad_history_${user.id}`, JSON.stringify(updatedHistory));

    // Award direct bonus database sync
    apiService.awardDirectBonus(user.id, rewardBdt, 'Premium Video Ad reward')
      .then(() => {
        onRefreshTrigger();
        fireAlert(
          'অভিনন্দন! 🎉',
          `আপনি সফলভাবে অ্যাড ভিউ থেকে ৳ ${rewardBdt.toFixed(2)} পেয়েছেন। এটি আপনার অ্যাড জব ব্যালেন্সে যোগ করা হয়েছে।`,
          'success'
        );
      })
      .catch((err) => {
        console.error(err);
        fireAlert(
          'সার্ভার সফল! ✔',
          `আপনি সফলভাবে অ্যাড ভিউ থেকে ৳ ${rewardBdt.toFixed(2)} পেয়েছেন।`,
          'success'
        );
      });
  };

  const fireAlert = (title: string, text: string, icon: 'success' | 'error' | 'warning' | 'info') => {
    const Swal = (window as any).Swal;
    if (Swal) {
      Swal.fire({
        title,
        text,
        icon,
        confirmButtonText: 'ঠিক আছে',
        customClass: {
          popup: 'rounded-3xl border border-blue-500/20 font-sans'
        }
      });
    } else {
      alert(`${title}\n${text}`);
    }
  };

  // Balance transfer to Main Wallet
  const handleTransfer = async () => {
    setTransferError('');
    setTransferSuccess('');
    const amt = parseFloat(transferAmount);

    if (isNaN(amt) || amt <= 0) {
      setTransferError('সঠিক ট্রান্সফার পরিমাণ লিখুন!');
      return;
    }

    if (amt > adBalance) {
      setTransferError('আপনার অ্যাড জব ব্যালেন্সের চেয়ে বেশি ট্র্যান্সফার করা সম্ভব নয়!');
      return;
    }

    if (amt < 5) {
      setTransferError('সর্বনিম্ন ৫.০০ টাকা ট্রান্সফার করতে হবে!');
      return;
    }

    try {
      // Deduct ad balance locally
      setAdBalance(prev => prev - amt);
      setTransferAmount('');

      // Add to main wallet DB
      const res = await apiService.awardDirectBonus(user.id, amt, 'Transfer from Ad Job Balance');
      if (res.success) {
        onRefreshTrigger();
        setTransferSuccess(`সফলভাবে ৳ ${amt.toFixed(2)} টাকা আপনার প্রধান ওয়ালেটে ট্রান্সফার করা হয়েছে!`);
        fireAlert('ট্রান্সফার সফল BDT! 💸', `৳ ${amt.toFixed(2)} টাকা সরাসরি আপনার প্রধান ওয়ালেট ব্যালেন্সে ট্রান্সফার সম্পন্ন হয়েছে।`, 'success');
      } else {
        throw new Error(res.error || 'DB Transfer Error');
      }
    } catch (e: any) {
      console.error(e);
      setTransferError('ওয়ালেটে সরাসরি সিঙ্ক করা যায়নি। অনুগ্রহ করে নেট চেক করুন।');
    }
  };

  return (
    <div className="w-full max-w-[500px] mx-auto px-4 font-sans pb-10">
      
      {/* Back to Home Button */}
      {onBack && (
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 text-gray-700 hover:text-blue-600 font-extrabold text-xs mb-5 bg-gray-50 hover:bg-gray-100 px-4 py-2 rounded-xl border border-gray-100 transition-all cursor-pointer self-start select-none shadow-sm"
        >
          <i className="fa-solid fa-arrow-left text-xs" />
          <span>ড্যাশবোর্ডে ফিরে যান</span>
        </button>
      )}

      {/* Nav Box subtabs inside page */}
      <div className="flex gap-2.5 mb-6">
        <button 
          onClick={() => setActiveSubTab('ad_panel')}
          className={`flex-1 py-3 px-2 rounded-xl text-center text-xs sm:text-xs font-bold transition-all cursor-pointer shadow-sm border ${activeSubTab === 'ad_panel' ? 'bg-blue-600 text-white border-blue-600 font-black' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'}`}
        >
          <i className="fa-solid fa-play text-xs mr-1" />
          বিজ্ঞাপন টাস্ক
        </button>
        <button 
          onClick={() => setActiveSubTab('history')}
          className={`flex-1 py-3 px-2 rounded-xl text-center text-xs sm:text-xs font-bold transition-all cursor-pointer shadow-sm border ${activeSubTab === 'history' ? 'bg-blue-600 text-white border-blue-600 font-black' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'}`}
        >
          <i className="fa-solid fa-history text-xs mr-1" />
          হিস্ট্রি (History)
        </button>
        <button 
          onClick={() => setActiveSubTab('transfer')}
          className={`flex-1 py-3 px-2 rounded-xl text-center text-xs sm:text-xs font-bold transition-all cursor-pointer shadow-sm border ${activeSubTab === 'transfer' ? 'bg-blue-600 text-white border-blue-600 font-black' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'}`}
        >
          <i className="fa-solid fa-paper-plane text-xs mr-1" />
          ট্রান্সফার (Transfer)
        </button>
      </div>

      {activeSubTab === 'ad_panel' && (
        <div className="space-y-5 animate-fade-in">
          
          {/* Ad Stats card */}
          <div className="bg-white border border-gray-200/90 rounded-2xl p-4 flex justify-between items-center shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 bg-blue-50 text-blue-600 border border-blue-100 rounded-xl flex items-center justify-center text-lg shadow-inner">
                <i className="fa-solid fa-wallet" />
              </div>
              <div>
                <span className="text-[11px] text-gray-500 font-bold block leading-tight">অ্যাড জব ব্যালেন্স</span>
                <span className="text-base font-black text-gray-900 font-mono">৳ {adBalance.toFixed(2)} BDT</span>
              </div>
            </div>

            <div className="flex items-center gap-3 border-l border-gray-100 pl-4">
              <div className="w-11 h-11 bg-orange-50 text-orange-600 border border-orange-100 rounded-xl flex items-center justify-center text-lg shadow-inner">
                <i className="fa-solid fa-eye" />
              </div>
              <div>
                <span className="text-[11px] text-gray-500 font-bold block leading-tight">বিজ্ঞাপন দেখা হয়েছে</span>
                <span className="text-base font-black text-gray-900 font-mono">
                  {adsWatched} <span className="text-xs text-gray-400 font-bold font-sans">/ ২৫ বার</span>
                </span>
              </div>
            </div>
          </div>

          {/* Ad Main Card layout */}
          <div className="bg-white border border-gray-200 shadow-sm rounded-2xl p-6 sm:p-7 text-center relative overflow-hidden">
            <div className="w-16 h-16 bg-blue-50 text-blue-600 border border-blue-100 rounded-full flex items-center justify-center text-2xl mx-auto mb-4 shadow-sm">
              <i className="fa-solid fa-rectangle-ad text-blue-600" />
            </div>

            <h2 className="text-lg font-black text-gray-800 tracking-tight mb-1.5 font-sans">Premium Video Ad BD</h2>
            <p className="text-xs text-gray-500 font-medium leading-relaxed mb-6 font-sans">
              বাটনে ক্লিক করে বিজ্ঞাপনটি সম্পূর্ণ দেখুন এবং ব্যালেন্সে অ্যাড মানি টাকা আয় করুন।
            </p>

            {/* Reward spec grids */}
            <div className="grid grid-cols-2 gap-3.5 mb-6">
              <div className="bg-blue-50/40 border border-blue-100 px-3.5 py-3 rounded-xl text-left flex items-center gap-2.5">
                <i className="fa-solid fa-coins text-blue-600 text-lg shadow-sm" />
                <div>
                  <span className="text-[10px] text-gray-500 font-bold block">টাস্ক রিওয়ার্ড:</span>
                  <span className="text-xs font-black text-blue-700 font-sans">৳ ০.৩০ BDT</span>
                </div>
              </div>
              <div className="bg-blue-50/40 border border-blue-100 px-3.5 py-3 rounded-xl text-left flex items-center gap-2.5">
                <i className="fa-solid fa-clock text-blue-600 text-lg shadow-sm" />
                <div>
                  <span className="text-[10px] text-gray-500 font-bold block">সময়সীমা:</span>
                  <span className="text-xs font-black text-blue-700 font-sans">৩০ সেকেন্ড (30s)</span>
                </div>
              </div>
            </div>

            {/* Interactive Timer countdown animation block */}
            {isWatching && (
              <div className="mb-6 p-4 bg-blue-50/50 border border-blue-100 rounded-xl space-y-2 animate-fade-in">
                <div className="flex justify-between items-center">
                  <span className="text-[11px] text-blue-700 font-bold">অ্যাড প্লেয়িং সময়সীমা</span>
                  <span className="text-lg font-black text-blue-600 font-mono tracking-wider">{timeLeft}s</span>
                </div>
                <div className="w-full h-2 bg-blue-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-blue-600 transition-all duration-1000 linear" 
                    style={{ width: `${((30 - timeLeft) / 30) * 100}%` }}
                  />
                </div>
              </div>
            )}

            {/* Action launcher triggering button */}
            {isCheckingSecurity ? (
              <button
                disabled
                className="w-full py-3 px-6 bg-blue-50 border border-blue-200 text-blue-600 font-bold text-xs sm:text-sm rounded-xl flex items-center justify-center gap-2"
              >
                <span className="w-4 h-4 rounded-full border-2 border-blue-600 border-t-transparent animate-spin" />
                <span>Checking Ad Security...</span>
              </button>
            ) : isWatching ? (
              <button
                disabled
                className="w-full py-3 px-6 bg-orange-100 border border-orange-200 text-orange-700 font-extrabold text-xs sm:text-sm rounded-xl animate-pulse flex items-center justify-center gap-2"
              >
                <i className="fa-solid fa-video text-xs mr-0.5" />
                <span>বিজ্ঞাপন লোড হয়েছে, দেখার পর রিওয়ার্ড পাবেন ({timeLeft}s)</span>
              </button>
            ) : adsWatched >= 25 ? (
              <button
                disabled
                className="w-full py-3 px-6 bg-gray-100 border border-gray-200 text-gray-400 font-bold text-xs sm:text-sm rounded-xl"
              >
                <i className="fa-solid fa-circle-check text-xs mr-1" />
                লিমিট শেষ (পরে আবার চেষ্টা করুন)
              </button>
            ) : (
              <button
                onClick={startAdWatching}
                className="w-full py-3.5 px-6 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs sm:text-sm rounded-xl transition-all font-sans cursor-pointer flex items-center justify-center gap-1.5 shadow-md shadow-blue-200 hover:-translate-y-0.5"
              >
                <i className="fa-solid fa-circle-play text-xs" />
                <span>View Ad Now (৳ ০.৩০)</span>
              </button>
            )}

            {/* Info Rules Warning notice */}
            <div className="mt-5 p-3.5 bg-red-50/50 border border-dashed border-red-200 rounded-xl flex gap-2.5 text-left">
              <i className="fa-solid fa-circle-info text-red-500 text-base shrink-0 mt-0.5" />
              <p className="text-[11px] text-gray-600 leading-normal font-sans">
                <strong className="text-red-700">কাজের নিয়ম:</strong> "View Ad Now" বাটনে ক্লিক করে বিজ্ঞাপনটি মিনিমাইজ না করে সম্পূর্ণ ৩০ সেকেন্ড দেখুন। এবং অবশ্যই অ্যাড ওপেন হলে লিঙ্কের ভেতর ক্লিক করতে হবে। অন্য ট্যাবে চলে গেলে আপনার কাজ সফল হবে না।
              </p>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'history' && (
        <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm space-y-4 animate-fade-in">
          <div>
            <h4 className="text-sm font-black text-gray-800">অ্যাড ভিউ টাস্ক হিস্ট্রি</h4>
            <p className="text-[10px] text-gray-400 font-medium font-sans">আপনার করা সাম্প্রতিক পেমেন্ট রিওয়ার্ড তালিকা</p>
          </div>

          <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
            {historyList.length === 0 ? (
              <div className="text-center py-8 text-gray-400 text-xs font-medium">কোনো হিস্ট্রি রেকর্ড পাওয়া যায়নি!</div>
            ) : (
              historyList.map(item => (
                <div key={item.id} className="p-3 bg-gray-50 border border-gray-100 rounded-xl flex justify-between items-center text-xs">
                  <div>
                    <span className="font-extrabold text-gray-800 block leading-tight">{item.platform}</span>
                    <span className="text-[10px] text-gray-400 font-mono block mt-1">সময়: {item.time} Today</span>
                  </div>
                  <div className="text-right">
                    <span className="font-black text-green-600 font-mono text-xs">+৳ {item.amount.toFixed(2)}</span>
                    <span className="text-[9px] text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-md border border-emerald-100/60 block mt-1 font-bold">ভেরিফাইড</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {activeSubTab === 'transfer' && (
        <div className="bg-white border border-gray-200 rounded-2xl p-5 shadow-sm space-y-4 animate-fade-in">
          <div>
            <h4 className="text-sm font-black text-gray-800">অ্যাড জব ব্যালেন্স ট্রান্সফার</h4>
            <p className="text-[10px] text-gray-400 font-medium font-sans">আপনার অ্যাড জব ব্যালেন্সটি সরাসরি মেইন ব্যালেন্সে ট্রান্সফার করুন</p>
          </div>

          <div className="p-4 bg-blue-50/50 border border-blue-100 rounded-xl text-center">
            <span className="text-[11px] text-gray-500 font-bold block">ট্রান্সফারোপোযোগী অ্যাড ব্যালেন্সঃ</span>
            <span className="text-lg font-black text-blue-700 font-mono tracking-wide">৳ {adBalance.toFixed(2)} BDT</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-[11px] font-bold text-gray-600 block mb-1">ট্রান্সফার পরিমাণ (৳):</label>
              <input 
                type="number"
                value={transferAmount}
                min="5"
                step="0.1"
                onChange={(e) => setTransferAmount(e.target.value)}
                placeholder="নিম্নে ৫.০০ টাকা"
                className="w-full px-3.5 py-2.5 border border-gray-200 rounded-xl text-xs font-sans outline-none focus:border-blue-500 text-gray-800 font-bold bg-gray-50"
              />
              <span className="text-[9px] text-gray-400 font-sans block mt-1 leading-normal">
                💡 ন্যূনতম ৫.০০ টাকা হলে আপনি ইনস্ট্যান্ট প্রধান ব্যালেন্সে টাকাটি পাঠাতে পারবেন। কোনো ফী কাটা হবে না।
              </span>
            </div>

            {transferError && (
              <p className="p-2 bg-red-50 text-red-700 border border-red-100 text-[11px] font-bold rounded-xl text-center">
                {transferError}
              </p>
            )}

            {transferSuccess && (
              <p className="p-2 bg-emerald-50 text-emerald-800 border border-emerald-100 text-[11px] font-bold rounded-xl text-center">
                {transferSuccess}
              </p>
            )}

            <button 
              onClick={handleTransfer}
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs sm:text-xs rounded-xl shadow transition-all cursor-pointer text-center flex justify-center items-center gap-1.5"
            >
              <i className="fa-solid fa-paper-plane" />
              <span>প্রধান ওয়ালেটে ব্যালেন্স পাঠান</span>
            </button>
          </div>
        </div>
      )}

    </div>
  );
}
