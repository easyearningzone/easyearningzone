import React, { useState, useEffect } from 'react';
import { User as UserIcon, Smartphone, Mail, UserCheck, Copy, Check, Save, Coins, ShieldCheck, Award, Sparkles, Loader2, HelpCircle, Camera } from 'lucide-react';
import { apiService } from '../lib/db';
import { User } from '../types';

interface ProfileSystemProps {
  user: User;
  onProfileUpdate: (updatedUser: User) => void;
}

interface AvatarPreset {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
  gradient: string;
}

export default function ProfileSystem({ user, onProfileUpdate }: ProfileSystemProps) {
  const [fullName, setFullName] = useState<string>(user.full_name || '');
  const [avatarUrl, setAvatarUrl] = useState<string>(user.avatar_url || '');
  const [saving, setSaving] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  
  // Leader info states
  const [leader, setLeader] = useState<User | null>(null);
  const [loadingLeader, setLoadingLeader] = useState<boolean>(false);

  // Avatar presets using Lucide icons and beautiful Tailwind CSS gradients
  const avatarPresets: AvatarPreset[] = [
    { id: 'hustler', name: 'BD Hustler', icon: UserIcon, gradient: 'from-cyan-500 to-blue-600' },
    { id: 'earner', name: 'Gold Earner', icon: Coins, gradient: 'from-yellow-400 to-amber-600' },
    { id: 'verified', name: 'Verified Pro', icon: UserCheck, gradient: 'from-emerald-400 to-teal-600' },
    { id: 'king', name: 'VIP King', icon: Award, gradient: 'from-purple-500 to-pink-500' },
    { id: 'guardian', name: 'Shield Elite', icon: ShieldCheck, gradient: 'from-indigo-500 to-purple-600' },
    { id: 'spark', name: 'Hustle Master', icon: Sparkles, gradient: 'from-pink-500 to-rose-600' },
  ];

  // Fetch leader details on load or referred_by_code change
  useEffect(() => {
    async function fetchLeader() {
      if (!user.referred_by_code) {
        setLeader(null);
        return;
      }
      setLoadingLeader(true);
      try {
        const leaderData = await apiService.getLeaderDetails(user.referred_by_code);
        setLeader(leaderData);
      } catch (err) {
        console.error('Error fetching leader details in ui:', err);
      } finally {
        setLoadingLeader(false);
      }
    }
    fetchLeader();
  }, [user.referred_by_code]);

  const handleCopyReferral = () => {
    if (!user.referral_code) return;
    navigator.clipboard.writeText(user.referral_code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const result = await apiService.updateUserProfile(user.id, {
        full_name: fullName.trim(),
        avatar_url: avatarUrl.trim()
      });

      if (result.success && result.user) {
        onProfileUpdate(result.user);
        const Swal = (window as any).Swal;
        if (Swal) {
          Swal.fire({
            icon: 'success',
            title: 'প্রোফাইল আপডেট হয়েছে!',
            text: 'আপনার প্রোফাইল সফলভাবে সংরক্ষণ করা হয়েছে।',
            background: '#0c0214',
            color: '#fce7f3',
            confirmButtonColor: '#06b6d4'
          });
        } else {
          alert('প্রোফাইল সফলভাবে সংরক্ষণ করা হয়েছে!');
        }
      } else {
        alert(result.error || 'প্রোফাইল সেভ করতে সমস্যা হয়েছে।');
      }
    } catch (err: any) {
      console.error(err);
      alert('একটি ত্রুটি দেখা দিয়েছে: ' + err.message);
    } finally {
      setSaving(false);
    }
  };

  const isPresetSelected = (preset: AvatarPreset) => {
    return avatarUrl === preset.id;
  };

  // Render current avatar helper
  const renderAvatarPreview = () => {
    const matchedPreset = avatarPresets.find(p => p.id === avatarUrl);
    if (matchedPreset) {
      const IconComp = matchedPreset.icon;
      return (
        <div className={`w-28 h-28 rounded-2xl bg-gradient-to-tr ${matchedPreset.gradient} flex items-center justify-center text-white shadow-xl shadow-cyan-500/10 border-2 border-white/20 relative group-hover:scale-105 transition-all duration-300`}>
          <IconComp className="w-12 h-12" />
        </div>
      );
    } else if (avatarUrl && avatarUrl.startsWith('http')) {
      return (
        <img
          src={avatarUrl}
          alt="Profile Avatar"
          referrerPolicy="no-referrer"
          className="w-28 h-28 rounded-2xl object-cover shadow-xl border-2 border-cyan-500/30 relative group-hover:scale-105 transition-all duration-300"
          onError={() => setAvatarUrl('')} // Reset on error
        />
      );
    } else {
      // Default initial-based avatar fallback
      return (
        <div className="w-28 h-28 rounded-2xl bg-gradient-to-tr from-cyan-500 to-emerald-500 flex items-center justify-center text-white font-bold text-3xl shadow-xl shadow-cyan-500/10 border-2 border-white/20 relative group-hover:scale-105 transition-all duration-300">
          {user.username ? user.username.charAt(0).toUpperCase() : 'U'}
        </div>
      );
    }
  };

  return (
    <div className="space-y-8 animate-fade-in font-sans">
      
      {/* Decorative Title & Premium Subtitle */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-white/5 pb-5">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight flex items-center gap-2">
            <span>👤 প্রোফাইল সেটিংস</span>
            <span className="text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 rounded-md px-2 py-0.5 font-mono uppercase">User Profile</span>
          </h2>
          <p className="text-xs text-gray-400 mt-1">আপনার ব্যক্তিগত তথ্য এবং রেফারেল লিডারবোর্ড বিস্তারিত দেখুন ও এডিট করুন।</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Form & Avatar selection */}
        <div className="lg:col-span-8 space-y-6">
          <form onSubmit={handleSaveProfile} className="bg-slate-900/60 border border-white/5 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl backdrop-blur-md">
            
            <div id="profile-picture-section" className="flex flex-col sm:flex-row items-center gap-6 pb-6 border-b border-white/5">
              <div className="group shrink-0">
                {renderAvatarPreview()}
              </div>
              <div className="space-y-2 text-center sm:text-left">
                <h3 className="text-white text-sm font-bold">প্রোফাইল পিকচার সিলেক্ট করুন</h3>
                <p className="text-gray-400 text-xs">আমাদের ডিজাইনকৃত প্রিমিয়াম আর্নিং এভাটার থেকে একটি সিলেক্ট করুন অথবা নিচে কাস্টম URL ব্যবহার করুন।</p>
                
                {/* Preset Avatars Selection Grid */}
                <div className="grid grid-cols-6 gap-2 mt-3 p-1.5 bg-black/40 rounded-xl border border-white/5">
                  {avatarPresets.map((preset) => {
                    const PresetIcon = preset.icon;
                    const selected = isPresetSelected(preset);
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => setAvatarUrl(preset.id)}
                        title={preset.name}
                        className={`aspect-square rounded-lg bg-gradient-to-tr ${preset.gradient} flex items-center justify-center text-white transition-all cursor-pointer hover:scale-110 active:scale-95 border-2 ${
                          selected ? 'border-cyan-400 shadow-md shadow-cyan-400/20' : 'border-transparent opacity-60 hover:opacity-100'
                        }`}
                      >
                        <PresetIcon className="w-5 h-5" />
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Inputs grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <div className="space-y-1.5">
                <label className="text-xs text-gray-400 font-bold flex items-center gap-1">
                  <Smartphone className="w-3.5 h-3.5 text-pink-400" />
                  <span>মোবাইল নম্বর (লকড - পরিবর্তনযোগ্য নয়):</span>
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={`+88 ${user.phone}`}
                    disabled
                    readOnly
                    className="w-full px-4 py-3 bg-black/50 border border-white/10 rounded-xl text-sm text-gray-400 font-mono focus:outline-none cursor-not-allowed select-none"
                  />
                  <div className="absolute right-3 top-3.5 text-[9px] font-mono text-cyan-400/80 bg-cyan-500/5 border border-cyan-400/20 px-1.5 py-0.5 rounded uppercase font-bold">
                    LOCKED
                  </div>
                </div>
                <p className="text-[10px] text-gray-500 font-sans">নিরাপত্তার স্বার্থে রেজিস্ট্রেশনকৃত পেমেন্ট মোবাইল নম্বর এডমিন ব্যতিত পরিবর্তন করা যাবে না।</p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-gray-400 font-bold flex items-center gap-1">
                  <UserIcon className="w-3.5 h-3.5 text-cyan-400" />
                  <span>আপনার সম্পূর্ণ নাম:</span>
                </label>
                <input
                  type="text"
                  placeholder="যেমনঃ আব্দুর রহমান"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full px-4 py-3 bg-black/30 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-cyan-500 transition-all font-sans"
                  required
                />
                <p className="text-[10px] text-gray-500 font-sans">যা সার্টিফিকেশন ও পেমেন্ট ভেরিফিকেশনে ব্যবহৃত হবে।</p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-gray-400 font-bold flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-purple-400" />
                  <span>ইমেইল এড্রেস:</span>
                </label>
                <input
                  type="email"
                  value={user.email}
                  disabled
                  readOnly
                  className="w-full px-4 py-3 bg-black/50 border border-white/10 rounded-xl text-sm text-gray-400 focus:outline-none cursor-not-allowed select-all"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-gray-400 font-bold flex items-center gap-1">
                  <Camera className="w-3.5 h-3.5 text-blue-400" />
                  <span>কাস্টম ছবি লিঙ্ক (ঐচ্ছিক ইমেজ URL):</span>
                </label>
                <input
                  type="url"
                  placeholder="যেমনঃ https://example.com/photo.jpg"
                  value={avatarUrl.startsWith('http') ? avatarUrl : ''}
                  onChange={(e) => setAvatarUrl(e.target.value)}
                  className="w-full px-4 py-3 bg-black/30 border border-white/10 rounded-xl text-sm text-white focus:outline-none focus:border-cyan-500 transition-all font-mono"
                />
              </div>
            </div>

            {/* Custom Referral showcase block inside Left Column */}
            <div className="p-4 bg-gradient-to-r from-cyan-950/40 to-slate-900 border border-cyan-500/20 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 sm:p-2.5 bg-cyan-500/10 border border-cyan-500/20 rounded-lg text-cyan-400">
                  <Coins className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-white text-xs font-bold font-sans">আপনার এক্সক্লুসিভ রেফার কোড (Your Referral Code)</h4>
                  <p className="text-gray-400 text-xs font-mono select-all font-bold mt-0.5">{user.referral_code || 'EEBD-NONE'}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={handleCopyReferral}
                className={`py-2 px-4 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-all shrink-0 ${
                  copied 
                    ? 'bg-emerald-500 text-slate-950 font-bold' 
                    : 'bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400 shadow-md shadow-cyan-500/10'
                }`}
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>কপি করা হয়েছে</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>কোড কপি করুন</span>
                  </>
                )}
              </button>
            </div>

            {/* Action button */}
            <div className="flex justify-end pt-3">
              <button
                type="submit"
                disabled={saving}
                className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-bold text-sm rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-cyan-500/10 disabled:opacity-50 cursor-pointer"
              >
                {saving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
                    <span>সংরক্ষণ করা হচ্ছে...</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 text-slate-950" />
                    <span>তথ্য সংরক্ষণ করুন</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>


        {/* Right Column: Leader details (She jar refer code diye account khulse) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-slate-900/60 border border-white/5 rounded-2xl p-6 shadow-xl backdrop-blur-md flex flex-col justify-between h-full space-y-4">
            
            <div>
              <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                <div className="p-1.5 bg-yellow-400/10 border border-yellow-400/20 rounded-lg text-yellow-400">
                  <UserIcon className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-white text-sm font-bold font-sans">আপনার টিম লিডার (My Ref Leader)</h3>
                  <p className="text-[10px] text-gray-400">আপনি যার রেফারেল কোড ব্যবহার করে অ্যাকাউন্ট খুলেছিলেন</p>
                </div>
              </div>

              <div className="pt-4 space-y-4">
                {loadingLeader ? (
                  <div className="flex flex-col items-center justify-center py-10 space-y-2 text-center">
                    <Loader2 className="w-6 h-6 animate-spin text-cyan-400" />
                    <p className="text-xs text-gray-400">লিডারের তথ্য লোড হচ্ছে...</p>
                  </div>
                ) : leader ? (
                  <div className="space-y-4 animate-fade-in font-sans">
                    
                    {/* Leader Avatar & Name Box */}
                    <div className="flex items-center gap-3.5 bg-white/5 p-3 rounded-xl border border-white/5">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-yellow-500 to-amber-600 flex items-center justify-center font-bold text-white text-lg shadow-md uppercase">
                        {leader.username ? leader.username.charAt(0) : 'L'}
                      </div>
                      <div>
                        <h4 className="text-white text-sm font-bold font-sans flex items-center gap-1">
                          <span>{leader.full_name || leader.username || 'টিম লিডার'}</span>
                          {leader.is_verified && (
                            <span className="inline-flex items-center" title="Verified Professional User">
                              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 fill-emerald-950/20" />
                            </span>
                          )}
                        </h4>
                        <p className="text-gray-400 text-xs font-mono mt-0.5">@{leader.username}</p>
                      </div>
                    </div>

                    {/* Detailed info items */}
                    <div className="space-y-2.5 pt-1 text-xs">
                      <div className="flex justify-between items-center bg-black/20 p-2.5 rounded-lg border border-white/5">
                        <span className="text-gray-400">মোবাইল নম্বর:</span>
                        <span className="text-pink-300 font-mono select-all font-bold">+88 {leader.phone}</span>
                      </div>
                      
                      <div className="flex justify-between items-center bg-black/20 p-2.5 rounded-lg border border-white/5">
                        <span className="text-gray-400">মেইল এড্রেস:</span>
                        <span className="text-cyan-300 font-mono select-all truncate max-w-[140px] md:max-w-[160px]">{leader.email}</span>
                      </div>

                      <div className="flex justify-between items-center bg-black/20 p-2.5 rounded-lg border border-white/5">
                        <span className="text-gray-400">ভেরিফিকেশন লেভেল:</span>
                        <span className="text-yellow-400 font-sans font-bold bg-yellow-400/10 border border-yellow-400/20 px-2 py-0.5 rounded-md uppercase text-[10px]">
                          {leader.membership_level || 'Free'}
                        </span>
                      </div>
                      
                      <div className="flex justify-between items-center bg-black/20 p-2.5 rounded-lg border border-white/5">
                        <span className="text-gray-400">লিডার রেফার লক্ষ্য:</span>
                        <span className="text-emerald-400 font-mono font-bold select-none text-[10px] bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md">
                          {leader.referral_code}
                        </span>
                      </div>
                    </div>

                    <div className="p-3 bg-cyan-950/20 rounded-xl border border-cyan-500/10 text-[11px] text-gray-400 leading-relaxed max-w-full font-sans mt-4">
                      💡 <strong>পরামর্শঃ</strong> ফ্রিল্যান্স কাজ করতে কোনো প্রবলেমে পড়লে আপনার টিম লিডারের মেইল বা ফোনে সরাসরি যোগাযোগ করতে পারেন।
                    </div>

                  </div>
                ) : user.referred_by_code ? (
                  <div className="text-center py-6 space-y-2">
                    <p className="text-xs text-amber-400 font-medium font-sans">⚠️ লিডার অ্যাকাউন্টটির অস্তিত্ব নেই</p>
                    <p className="text-[11px] text-gray-500 leading-relaxed font-sans">
                      রেফার কোডটি <strong>({user.referred_by_code})</strong> ডেটাবেজ থেকে মুছে ফেলা বা পরিবর্তিত হয়েছে।
                    </p>
                  </div>
                ) : (
                  <div className="text-center py-8 px-2 space-y-3">
                    <div className="w-10 h-10 rounded-full bg-slate-900 border border-white/10 flex items-center justify-center mx-auto text-gray-400">
                      <HelpCircle className="w-5 h-5" />
                    </div>
                    <p className="text-xs text-gray-300 font-bold font-sans">আপনি কোনো রেফারেল কোড ছাড়াই সরাসরি অল্টারনেটিভ হিসাবে জয়েন করেছেন।</p>
                    <p className="text-[11px] text-gray-500 leading-relaxed font-sans">
                      আপনার কোনো ডিরেক্ট রেফারেল আপলাইন লিডার নেই। সাপোর্ট টিমের সাথে কন্ট্যাক্ট করার জন্য হেল্পডেস্ক বা ফেসবুক পেইজে যোগাযোগ করুন।
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Platform status indicator */}
            <div className="border-t border-white/5 pt-4 text-[11px] text-gray-500 font-mono flex justify-between items-center uppercase">
              <span>LEDGER SYSTEM</span>
              <span className="text-emerald-400">● SECURE SPLIT</span>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
